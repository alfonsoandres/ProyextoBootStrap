function myFunction() {
  alert("Todavia no se puede comprar.");

}

var miCarousel = document.getElementById('mi-carousel');
var carousel = new bootstrap.Carousel(miCarousel, {
interval: 3000
});
